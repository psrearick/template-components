!// Avoid `console` errors in browsers that lack a console.
function(){for(var e,n=function(){},o=["assert","clear","count","debug","dir","dirxml","error","exception","group","groupCollapsed","groupEnd","info","log","markTimeline","profile","profileEnd","table","time","timeEnd","timeline","timelineEnd","timeStamp","trace","warn"],i=o.length,r=window.console=window.console||{};i--;)// Only stub undefined methods.
r[e=o[i]]||(r[e]=n)}();// Place any jQuery/helper plugins in here.
//# sourceMappingURL=index.07722491.js.map

//# sourceMappingURL=index.07722491.js.map
